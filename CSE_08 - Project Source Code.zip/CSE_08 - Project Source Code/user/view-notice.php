<?php

$con = mysqli_connect("localhost", "root", "", "studentmsdb");
if (!$con) {
  die("Unable to Connect");
}

session_start();
//error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sturecmsstuid'] == 0)) {
  header('location:logout.php');
} else {

?>
  <!DOCTYPE html>
  <html lang="en">

  <head>

    <title>Student Management System|| View Result</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="vendors/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="vendors/select2/select2.min.css">
    <link rel="stylesheet" href="vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="css/style.css" />

  </head>

  <body id="idBody">
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <?php include_once('includes/header.php'); ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php include_once('includes/sidebar.php'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> View Result </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                  <li class="breadcrumb-item active" aria-current="page"> View Result</li>
                </ol>
              </nav>
            </div>
            <div class="row">

              <!-- <div class="col-12 grid-margin stretch-card">

                <div class="card">

                  <?php
                  $username = $_SESSION['login'];
                  echo "Username : $username";
                  ?>

                  <form class="forms-sample" method="post" enctype="multipart/form-data">

                    <?php
                    $s = "SELECT * FROM tblstudent WHERE UserName='$username'";
                    $rs = mysqli_query($con, $s);

                    while ($r = mysqli_fetch_array($rs)) {

                      echo " <table align='center' ><tr> <td> $username <img src='$r[14]' alt='Unable to load'> </td> </tr> </table>";
                    }
                    ?>

                    <div class="card-body">

                      <table border="1" class="table table-bordered mg-b-0">
                        <?php

                        $s = "SELECT * FROM tblstudent WHERE UserName='$username'";

                        $rs = mysqli_query($con, $s);

                        echo "<tr> <th> ID </th>";
                        echo "<th> NAME </th>";
                        echo "<th> EMAIL </th>";
                        echo "<th> CLASS </th> </tr>";

                        while ($r = mysqli_fetch_array($rs)) {
                          echo "<tr>";
                          echo "<td>$r[0]";
                          echo "<td>$r[1]";
                          echo "<td>$r[2]";
                          echo "<td>$r[3]";
                          echo "</tr>";
                        }

                        $s = "SELECT * FROM tblstudent WHERE UserName='$username'";

                        $rs = mysqli_query($con, $s);

                        echo "<tr> <th> D.O.B. </th>";
                        echo "<th> ROLL NO </th>";
                        echo "<th> Father's Name </th>";
                        echo "<th> Mother's Name </th> </tr>";

                        while ($r = mysqli_fetch_array($rs)) {
                          echo "<tr>";
                          echo "<td>$r[5]";
                          echo "<td>$r[6]";
                          echo "<td>$r[7]";
                          echo "<td>$r[8]";
                          echo "</tr>";
                        }

                        $s = "SELECT * FROM tblstudent WHERE UserName='$username'";

                        $rs = mysqli_query($con, $s);

                        echo "<th> HINDI </th>";
                        echo "<th> ENGLISH </th>";
                        echo "<th> MATHS </th>";
                        echo "<th> SCIENCE </th>";
                        echo "</tr>";



                        while ($r = mysqli_fetch_array($rs)) {
                          echo "<tr>";
                          echo "<td>$r[16]";
                          echo "<td>$r[17]";
                          echo "<td>$r[18]";
                          echo "<td>$r[19]";
                          echo "</tr>";
                        }

                        ?>

                      </table>
                    </div>
                  </form>
                </div>

              </div> -->

              <!-- Usman Starts -->
              <div class="col-12 grid-margin stretch-card">
                <div class="card" id="resRow" >
                  <div class="card-body">

                    <table border="1" class="table table-bordered mg-b-0">
                      <?php
                      $sid = $_SESSION['sturecmsstuid'];
                      $sql = "SELECT tblstudent.StudentName,tblstudent.StudentEmail,tblstudent.StudentClass,tblstudent.Gender,tblstudent.DOB,tblstudent.StuID,tblstudent.FatherName,tblstudent.MotherName,tblstudent.ContactNumber,tblstudent.AltenateNumber,tblstudent.Address,tblstudent.UserName,tblstudent.Password,tblstudent.Image,tblstudent.DateofAdmission, tblstudent.Hindi, tblstudent.English, tblstudent.Maths, tblstudent.Science, tblclass.ClassName,tblclass.Section from tblstudent join tblclass on tblclass.ID=tblstudent.StudentClass where tblstudent.StuID=:sid";
                      $query = $dbh->prepare($sql);
                      $query->bindParam(':sid', $sid, PDO::PARAM_STR);
                      $query->execute();
                      $results = $query->fetchAll(PDO::FETCH_OBJ);
                      $cnt = 1;
                      if ($query->rowCount() > 0) {
                        foreach ($results as $row) {               ?>


                          <tr class="table-primary">
                            <!-- <th>Profile Pics</th> -->
                            <td colspan="4" align="center"><img src="../admin/images/<?php echo $row->Image; ?>"></td>
                            <!-- <th>Date of Admission</th>
                            <td><?php echo $row->DateofAdmission; ?></td> -->
                          </tr>

                          <tr align="center" class="table-warning">
                            <td colspan="4" style="font-size:20px;color:blue;">
                              <h1>STUDENT RESULT</h1>
                            </td>
                          </tr>

                          <tr class="table-primary">
                            <th>Student Name</th>
                            <td><?php echo $row->StudentName; ?></td>
                            <th>Student Email</th>
                            <td><?php echo $row->StudentEmail; ?></td>
                          </tr>
                          <tr class="table-danger">
                            <th>Student Class</th>
                            <td><?php echo $row->ClassName; ?> <?php echo $row->Section; ?></td>
                            <th>Gender</th>
                            <td><?php echo $row->Gender; ?></td>
                          </tr>
                          <tr class="table-success">
                            <th>Date of Birth</th>
                            <td><?php echo $row->DOB; ?></td>
                            <th>Student ID</th>
                            <td><?php echo $row->StuID; ?></td>
                          </tr>
                          <tr class="table-warning">
                            <th>Father Name</th>
                            <td><?php echo $row->FatherName; ?></td>
                            <th>Mother Name</th>
                            <td><?php echo $row->MotherName; ?></td>
                          </tr>
                          <tr class="table-success">
                            <th>Contact Number</th>
                            <td><?php echo $row->ContactNumber; ?></td>
                            <th>Altenate Number</th>
                            <td><?php echo $row->AltenateNumber; ?></td>
                          </tr>

                          <!-- Result Sheet -->
                          <tr class="table-danger">
                            <th>Hindi</th>
                            <td><?php echo $row->Hindi; ?></td>
                            <th>English</th>
                            <td><?php echo $row->Maths; ?></td>
                          </tr>
                          <tr class="table-primary">
                            <th>Maths</th>
                            <td><?php echo $row->Maths; ?></td>
                            <th>Science</th>
                            <td><?php echo $row->Science; ?></td>
                          </tr>


                          <tr class="table-progress">

                            <td colspan="4" align="center" class="button" id="btnPrint">
                              <button onclick="printResult()">Print Result</button>
                            </td>

                          </tr>



                          <!-- <tr class="table-progress">
                            <th>Address</th>
                            <td><?php echo $row->Address; ?></td>
                            <th>User Name</th>
                            <td><?php echo $row->UserName; ?></td>
                          </tr> -->
                          
                      <?php $cnt = $cnt + 1;
                        }
                      } ?>
                    </table>

                    <!-- Download Button Sript starts -->
                    <script>
                      function printResult() {
                        document.getElementById("btnPrint").style.display = "none"; 
                        var body = document.getElementById("idBody").innerHTML;
                        // alert(body);
                        var resultData = document.getElementById("resRow").innerHTML;
                        // alert(resultData);

                        document.getElementById("idBody").innerHTML = resultData;
                        // alert(resultData);
                        window.print();

                      }
                    </script>
                    <!-- Download Button Sript Ends -->
                  </div>
                </div>
              </div>
              <!-- Usman Ends -->
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <?php include_once('includes/footer.php'); ?>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="vendors/select2/select2.min.js"></script>
    <script src="vendors/typeahead.js/typeahead.bundle.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="js/off-canvas.js"></script>
    <script src="js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="js/typeahead.js"></script>
    <script src="js/select2.js"></script>
    <!-- End custom js for this page -->
  </body>

  </html><?php }  ?>