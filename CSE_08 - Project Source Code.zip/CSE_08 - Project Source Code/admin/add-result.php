<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
include('includes/conn.php');
if (strlen($_SESSION['sturecmsaid'] == 0)) {
  header('location:logout.php');
} else {
  if (isset($_POST['submit'])) {
    $studId = $_POST['studid'];
    $studName = $_POST['studname'];
    $hindi = $_POST['hindi'];
    $english = $_POST['english'];
    $maths = $_POST['maths'];
    $science = $_POST['science'];
    $userName = $_SESSION['login'];

    $sql = "UPDATE tblstudent SET Hindi = $hindi, English = $english, Maths = $maths, Science = $science WHERE StuID = '$studId';"; // Query By Usman (#NotWorking) 

    // OR = StudentName '$studName' : 


    // echo "\n\n The Update Query To Add Result Is : " . $sql . "\n\n";


    if (mysqli_query($con, $sql)) {
      echo "console.log('Test')";
      echo '<script>alert("Result Has Been Added.")</script>';
      echo "<script>window.location.href ='add-result.php'</script>";
    } else {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }

    mysqli_close($con);

    /*
    // $query = $dbh->prepare($sql);
    // $query->bindParam(':userName', $userName, PDO::PARAM_STR);
    // $query->bindParam(':id', $id, PDO::PARAM_STR);
    // $query->bindParam(':studname', $studName, PDO::PARAM_STR);
    // $query->bindParam(':hindi', $hindi, PDO::PARAM_STR);
    // $query->bindParam(':english', $english, PDO::PARAM_STR);
    // $query->bindParam(':maths', $maths, PDO::PARAM_STR);
    // $query->bindParam(':science', $science, PDO::PARAM_STR);
    // $query->execute();

    $LastInsertId = $dbh->lastInsertId();
    if ($LastInsertId > 0) {
      echo '<script>alert("Result Has Been Added.")</script>';
      echo "<script>window.location.href ='add-notice.php'</script>";
    } else {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
    */
  }
?>
  <!DOCTYPE html>
  <html lang="en">

  <head>

    <title>Student Management System|| Add Result</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="vendors/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="vendors/select2/select2.min.css">
    <link rel="stylesheet" href="vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="css/style.css" />

  </head>

  <body>

    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <?php include_once('includes/header.php'); ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <?php include_once('includes/sidebar.php'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">RESULT </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                  <li class="breadcrumb-item active" aria-current="page"> RESULT </li>
                </ol>
              </nav>
            </div>
            <div class="row">

              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <?php
                    $username = $_SESSION['login'];
                    ?>
                    <h4 class="card-title" style="text-align: center;">RESULT
                      <?php ?></h4>



                    <form class="forms-sample" method="post" enctype="multipart/form-data">



                      <div class="form-group">
                        <label for="exampleInputName1">Student ID</label>
                        <input type="text" name="studid" value="" class="form-control" required='true'>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1">Hindi</label>
                        <textarea name="hindi" value="" class="form-control" required='true'></textarea>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1">English</label>
                        <textarea name="english" value="" class="form-control" required='true'></textarea>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1">Maths</label>
                        <textarea name="maths" value="" class="form-control" required='true'></textarea>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1">Science</label>
                        <textarea name="science" value="" class="form-control" required='true'></textarea>
                      </div>


                      <button type="submit" class="btn btn-primary mr-2" name="submit">Add</button>

                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <?php include_once('includes/footer.php'); ?>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject - Plugin js for this page  -->
    <script src="vendors/select2/select2.min.js"></script>
    <script src="vendors/typeahead.js/typeahead.bundle.min.js"></script>
    <!-- End plugin js for this page  -->
    <!-- inject:js -->
    <script src="js/off-canvas.js"></script>
    <script src="js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="js/typeahead.js"></script>
    <script src="js/select2.js"></script>
    <!-- End custom js for this page -->
  </body>

  </html><?php }  ?>