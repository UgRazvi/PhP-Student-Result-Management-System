<?php


$con = mysqli_connect("localhost", "root", "", "studentmsdb");
if (!$con) {
    die("Unable to Connect");
}
